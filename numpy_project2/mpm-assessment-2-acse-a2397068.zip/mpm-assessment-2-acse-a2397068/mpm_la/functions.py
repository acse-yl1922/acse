__all__ = ["det", "mult", "adj", "inv", "solve", "solve_opt"]

import copy

import numpy as np


def det(a):
    """
    Given a martix `a`, return its determinat or `None` if its
    determinant does not exist.

    Parameters
    ----------
    a : np.array or list of lists
        'n x m' array

    Returns
    -------
    deter : np.float64 or None
        The determinant of `a`.

    Examples
    --------
    >>> a = [[2, 0, -1], [0, 5, 6], [0, -1, 1]]
    >>> d = det(a)
    >>> d
    22.0

    >>> a = [[2, 3, 7, 9], [0, 0, 2, 4], [0, 1, 5, 0], [0, 0, 0, 3]]
    >>> b = det(a)
    >>> b
    -12.0

    >>> a = [[2, 3],[0, 3]]
    >>> b = det(a)
    >>> b
    6.0

    >>> a = [[2]]
    >>> b = det(a)
    >>> b
    2.0

    Notes
    -----
    See https://en.wikipedia.org/wiki/Gaussian_elimination for further details.
    """
    # calculate determinants
    a = np.array(copy.deepcopy(a), dtype=float)
    # print("a=",a)

    # only handle 2-D array
    if a.ndim == 2:
        # a = [[]]
        if a.size == 0:
            # print("size0")
            return None

        row_size, col_size = a.shape
        # a is one dimention
        if a.shape == (1, 1):
            # print("size1")
            return a[0][0]
        else:
            deter = None
            if row_size == 2:
                deter = a[0][0] * a[1][1] - a[0][1] * a[1][0]
                # print("size2: det = ",det)
                return deter
            # for square matrix only
            elif row_size == col_size:
                deter = 0
                # from fixed i=1, row_1 (a[0])
                for j in range(col_size):
                    det_next = (
                        (-1) ** (0 + j)
                        * a[0][j]
                        * det(np.concatenate(
                            (a[1:, :j], a[1:, j + 1:]), axis=1))
                    )
                    deter = deter + det_next
                    # print("det:[","a",a,"[j",j,"det_next=:",det_next)
                return deter
    else:
        return None


def mult(a, b):
    """
    Given two matrixes 'a' and 'b', return their Multiplication

    Parameters
    ----------
    a : np.array or list of lists
        'n x m' array

    b : np.array or list of lists
        'm x l' array

    Returns
    ----------
    c : np.array or None
        'n x l' array, the multiplacation of a and b

    Examples
    ----------
    >>> a = [[1, 2], [3, 4]]
    >>> b = [[5], [6]]
    >>> c = mult(a, b)
    >>> c
    array([[17.],
           [39.]])

    >>> a = [[1, 2], [3, 4]]
    >>> b = [[5, 1], [6, 2]]
    >>> c = mult(a, b)
    >>> c
    array([[17.,  5.],
           [39., 11.]])
    """
    # copy a and b
    a = copy.deepcopy(np.array(a, dtype=float))
    b = copy.deepcopy(np.array(b, dtype=float))

    # only deal with 2D dimension
    if a.ndim == 2 and b.ndim == 2:
        a_n, a_m = a.shape
        b_m, b_l = b.shape
        # check dimension
        if a_m == b_m:
            c = np.zeros((a_n, b_l))
            for cn in range(a_n):
                for cl in range(b_l):
                    for m in range(a_m):
                        c[cn, cl] = c[cn, cl] + a[cn, m] * b[m, cl]
            return c
        else:
            # can not be mult
            return None

    else:
        # for non-2D dimension return None
        return None


def adj(a):
    """
    Given a martix `a`, return its adjugate matrix or
    `None` if its adjugate matrix does not exist.

    Parameters
    ----------
    a : np.array or list of lists
        'n x m' array

    Returns
    ----------
    m_adj : np.array or None
        'n x m' array, the adjugate of a

    Examples
    ----------
    >>> a = [[1, 0, -1], [-2, 3, 0], [1, -3, 2]]
    >>> m_adj = adj(a)
    >>> m_adj
    array([[6., 3., 3.],
           [4., 3., 2.],
           [3., 3., 3.]])

    >>> a = [[1, 1], [1, 1]]
    >>> m_adj = adj(a)
    >>> m_adj
    array([[ 1., -1.],
           [-1.,  1.]])

    """
    # copy a
    a = copy.deepcopy(np.array(a, dtype=float))

    # only deal with 2D square matrix
    if a.ndim == 2:
        n, m = a.shape
        if n == m:
            if n == 1:
                return [[1.]]
            else:
                m_adj = np.zeros((n, m))
                for i in range(n):
                    for j in range(m):
                        # get B_ij on A_ij
                        det_bij = np.concatenate(
                            (a[:, :j], a[:, j + 1:]), axis=1)
                        det_bij = np.concatenate(
                            (det_bij[:i, :], det_bij[i + 1:, :]), axis=0)
                        m_adj[i, j] = (-1) ** (i + j) * det(det_bij)
                        # print("m_adj[",i,"][",j,"]=",m_adj[i, j],"||A_ij=")
                        # print(det_bij)
                return m_adj.transpose()
        else:
            # not square matrix return None
            return None
    else:
        # for non-2D matrix return None
        return None


def inv(a):
    """
    Given a martix `a`, return its inverse matrix or
    `None` if its inverse matrix does not exist.

    Parameters
    ----------
    a : np.array or list of lists
        'n x n' array

    Returns
    ----------
    m_inv : np.array or None
        'n x m' array, the inverse matrix of a

    Examples
    ----------
    >>> a = [[1, 0, -1], [-2, 3, 0], [1, -3, 2]]
    >>> m_inv = inv(a)
    >>> m_inv
    array([[2.        , 1.        , 1.        ],
           [1.33333333, 1.        , 0.66666667],
           [1.        , 1.        , 1.        ]])

    >>> a = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    >>> m_inv = inv(a)
    >>> m_inv
    array([[ 1., -0.,  0.],
           [-0.,  1., -0.],
           [ 0., -0.,  1.]])
    """

    # copy a
    a = copy.deepcopy(np.array(a, dtype=float))

    # only deal with 2D square matrix
    if a.ndim == 2:
        n, m = a.shape
        if n == m:
            m_inv = adj(a)/det(a)
            return m_inv
        else:
            # not square matrix return None
            return None
    else:
        # for non-2D matrix return None
        return None


def solve(a, b):
    """
    Given two matrixes 'a' and 'b',
    return the solution of Ax = b using Cramer's rule
    where a is A

    Parameters
    ----------
    a : np.array or list of lists
        'n x m' 2D array

    b : np.array or list of lists
        'm x 1' 2D array

    Returns
    ----------
    x : np.array
        'm x 1' array, the multiplacation of a and b
        or None when a is not square matrix

    Examples
    ----------
    >>> a = [[1, 1, 1], [-1, 1, 1], [-1, -1, 1]]
    >>> b = [[1], [2], [-1]]
    >>> x = solve(a, b)
    >>> x
    array([[-0.5],
           [ 1.5],
           [ 0. ]])

    >>> a = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    >>> b = [[1], [2], [3]]
    >>> x = solve(a, b)
    >>> x
    array([[1.],
           [2.],
           [3.]])

    """

    # copy a
    a = copy.deepcopy(np.array(a, dtype=float))
    b = copy.deepcopy(np.array(b, dtype=float))

    # only deal with 2D square matrix
    if a.ndim == 2 and b.ndim == 2:
        # get shape of a and b
        a_n, a_m = a.shape
        b_m, b_l = b.shape

        a_det = det(a)
        # check constrains:
        # no solution
        if a_det is None:
            return None
        # a is n x n matrix and b is n x 1 matrix
        if a_n == a_m and b_m == a_n and b_l == 1:
            # initialize x
            x = np.zeros(b.shape)
            for i in range(x.shape[0]):
                B_i = copy.deepcopy(a)
                B_i[:, i] = b[:, 0]
                x[i] = det(B_i)/a_det
            return x
        else:
            # invalid shape of a or b
            return None
    else:
        # for non-2D matrix return None
        return None


def solve_opt(a, b):
    """
    Given two matrixes 'a' and 'b',
    return the solution of Ax = b
    !! This is a try on optimizing solve(a, b)

    Parameters
    ----------
    a : np.array or list of lists
        'n x m' 2D array

    b : np.array or list of lists
        'm x 1' 2D array

    Returns
    ----------
    x : np.array
        'm x 1' array, the multiplacation of a and b
        or None when a is not square matrix

    Examples
    ----------
    >>> a = [[1, 1, 1], [-1, 1, 1], [-1, -1, 1]]
    >>> b = [[1], [2], [-1]]
    >>> x = solve_opt(a, b)
    >>> x
    array([[-0.5],
           [ 1.5],
           [ 0. ]])

    >>> a = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    >>> b = [[1], [2], [3]]
    >>> x = solve_opt(a, b)
    >>> x
    array([[1.],
           [2.],
           [3.]])

    """
    # copy a
    a = copy.deepcopy(np.array(a, dtype=float))
    b = copy.deepcopy(np.array(b, dtype=float))

    # only deal with 2D square matrix
    if a.ndim == 2 and b.ndim == 2:
        # get shape of a and b
        a_n, a_m = a.shape
        b_m, b_l = b.shape

        a_det = det(a)
        # check constrains:
        # no solution
        if a_det is None:
            return None
        # a is n x n matrix and b is n x 1 matrix
        if a_n == a_m and b_m == a_n and b_l == 1:
            # initialize x
            x = np.zeros(b.shape)
            # using Gaussian elimination
            aug = np.concatenate((a, b), axis=1)
            # get augmented matrix
            aug = _elimination(aug)
            # get solution x
            x = _solve_aug(aug)
            return x
        else:
            # invalid shape of a or b
            return None
    else:
        # for non-2D matrix return None
        return None


def _elimination(aug):
    """ (Internal) This function is used to on Gaussian elimination"""
    # print(aug)
    aug_n, aug_m = aug.shape
    if aug.shape == (1, 2):
        aug = aug/aug[0, 0]
        # print("finish aug:",aug)
        return aug
    # search and move line with abv().max on the top
    i = 0
    top_line = np.argmax(np.abs(aug[:, 0]), axis=0)
    aug[0, :], aug[top_line, :] = aug[top_line, :].copy(), aug[0, :].copy()
    # change aug[i,0] to 1
    if aug[i][0] == 0:
        return None
        # print("out")
    aug = aug/aug[0][0]
    # update the rest element in this line is 0
    for j in range(1, aug_n-i):
        aug[j, :] = aug[j, :] - aug[j, i] * aug[i, :]
    # print(aug)
    # print(aug[1:,1:])
    aug[1:, 1:] = copy.deepcopy(_elimination(aug[1:, 1:]))
    return aug


def _solve_aug(aug):
    """ (Internal) This function is used to get solution on augmented metrix"""
    aug = copy.deepcopy(aug)
    aug_n, aug_m = aug.shape
    for i in range(aug_n, 0, -1):
        # backup col by col
        for j in range(i-1, 0, -1):
            aug[j-1, -1] = aug[j-1, -1] - aug[j-1, i-1] * aug[i-1, -1]
            aug[j-1, i-1] = 0
    return aug[:, -1].reshape((aug_n, 1))


if __name__ == "__main__":
    import doctest
    doctest.testmod()
