# This script helps generate doc [html and pdf] quickly

# html
sphinx-build -b html docs docs/html

# pdf
sphinx-build -b latex docs docs/pdf

# run twice to keep index work correctly
cd docs/pdf
pdflatex mpm_la.tex
pdflatex mpm_la.tex

cp *.pdf ./../  
