from importlib import import_module


def test_docstring():
    mod = import_module("mpm_la.functions")
    import doctest
    assert doctest.testmod(mod).failed == 0
