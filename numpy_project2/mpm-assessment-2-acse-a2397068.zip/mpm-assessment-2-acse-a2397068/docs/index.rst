Matrix operation and Cramer`s rule
***********************************

functions
========================

This module implements Cramer's rule for :obj:`list of lists` objects, along with hand-written matrix multiplication, Adjugate matrix, Determinant and Inverse. Gaussian elimination [1]_ is also used as an optimization.


See :func:`functions.det` , :func:`functions.mult`, :func:`functions.adj`, :func:`functions.inv`, :func:`functions.solve`, :func:`functions.solve_opt` for more information.

.. automodule:: mpm_la.functions
  :members: det, mult, adj, inv, solve, solve_opt

.. rubric:: References
.. [1] https://mathworld.wolfram.com/GaussianElimination.html
