# MPM assessment 2

## Mpm_la CW Introduction

<h3> File directory with main tasks shown</h3>
<pre>
.
├── README.md
├── assessement.pdf
├── .github/workflows
│   ├── anaconda_pytest.yml         # test in anaconda env
│   ├── PEP8.yml                    # check PEP8 compliant
│   ├── pytest_all.yml              # pytest on different os and py versions
│   └── shpinx.yml                  # build doc and push new html
├── docs
│   ├── conf.py                     # html doc config
│   ├── html                        # sphinx generated html
│   ├── index.rst                   # doc config
│   ├── mpm_la.pdf                  # sphinx generated PDF
│   └── pdf
├── environment.yml
├── examples
│   ├── introduction.ipynb          # introducing and demostrating
│   └── test_time.ipynb             # test run time and opt time in pandas
├── generate_doc.sh                 # generate doc quickly using bash
├── mpm_la
│   ├── __init__.py
│   ├── __pycache__
│   └── functions.py
├── mpm_la.egg-info
│   ├── PKG-INFO
│   ├── SOURCES.txt
│   ├── dependency_links.txt
│   └── top_level.txt
├── mytest.ipynb
├── reload_env.sh                   # reload enviroment quickly
├── requirements.txt
├── setup.py
└── tests
    ├── __pycache__             
    ├── test_docstrings.py          # doctest using module
    └── test_functions.py           # function test using pytest
</pre>


## Origion Note
This repository contains the material required to get you started with the
second, and final, assessment of Modern Programming Methods. Details of the assessment and the
associated marking scheme can be found in the file `assessment.pdf` located in the base folder
of this repository.

To complete this assignment, it is recommended that
you create a new virtual environment and install the required `Python` packages
within your virtual environment.

If you wish to create an `Anaconda` environment, an `environment.yml` file has
been provided from which you can create the `mpm_la` environment
by running
```bash
conda env create -f environment.yml
```
from within the base folder of this repository. If you wish to use some other virtual environment solution,
when in your environment ensure that all requirements are satisfied via
```bash
pip install -r requirements.txt
```

Following the installation of the requirements, the `mpm_la` package should be installed by running
```bash
pip install -e .
```
from within the base folder of this repository.

You can ensure the `mpm_la` package has been installed in the environment via
```bash
pip show mpm_la
```
