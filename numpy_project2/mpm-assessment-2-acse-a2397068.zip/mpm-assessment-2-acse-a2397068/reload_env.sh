# This bash script delete and reload new env in enviroment.yml
conda env remove -n mpm_la -y

# create env
conda env create -f environment.yml
# activate env
conda activate mpm_la

# reload requirements
pip install -r requirements.txt
pip install -e .
pip show mpm_la