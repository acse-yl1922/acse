import numpy as np
import pytest

from mpm_la.functions import adj, det, inv, mult, solve, solve_opt


class TestFunction(object):
    """This class test all functions in mpm_la.functions"""

    @pytest.mark.parametrize(
        "a, deter",
        [
            ([[2, 0, -1], [0, 5, 6], [0, -1, 1]], 22.0),
            ([[2, 3, 7, 9], [0, 0, 2, 4], [0, 1, 5, 0], [0, 0, 0, 3]], -12.0),
            ([[2, 3], [0, 3]], 6.0),
            ([[2]], 2.0),
            ([], None),
        ],
    )
    def test_det(self, a, deter):
        """Test the det function"""
        t_det = det(a)
        if t_det is None:
            assert t_det == deter
        else:
            assert np.isclose(t_det, deter).all()

    @pytest.mark.parametrize(
        "a, b, c",
        [
            ([[1, 2], [3, 4]], [[5], [6]], [[17.0], [39.0]]),
            ([[1, 2], [3, 4]], [[5, 1], [6, 2]], [[17.0, 5.0], [39.0, 11.0]]),
        ],
    )
    def test_mult(self, a, b, c):
        """Test the mult function"""
        t_mult = mult(a, b)
        if t_mult is None:
            assert t_mult == c
        else:
            assert np.allclose(t_mult, c)

    @pytest.mark.parametrize(
        "a, m_adj",
        [
            ([[1, 0, -1], [-2, 3, 0], [1, -3, 2]],
             [[6, 3, 3], [4, 3, 2], [3, 3, 3]]),
            ([[1, 1], [1, 1]], [[1, -1], [-1, 1]]),
        ],
    )
    def test_adj(self, a, m_adj):
        """Test the adj function"""
        t_adj = adj(a)
        if t_adj is None:
            assert t_adj == m_adj
        else:
            assert np.allclose(t_adj, m_adj)

    @pytest.mark.parametrize(
        "a, m_inv",
        [
            (
                [[1, 0, -1], [-2, 3, 0], [1, -3, 2]],
                [[2, 1, 1], [4 / 3, 1, 2 / 3], [1, 1, 1]],
            ),
            (
                [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
                [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
            )
        ],
    )
    def test_inv(self, a, m_inv):
        """Test the inv function"""
        t_inv = inv(a)
        if t_inv is None:
            assert t_inv == m_inv
        else:
            assert np.allclose(t_inv, m_inv)

    @pytest.mark.parametrize(
        "a, b, x",
        [
            (
                [[1, 1, 1], [-1, 1, 1], [-1, -1, 1]],
                [[1], [2], [-1]],
                [[-1 / 2], [3 / 2], [0]],
            ),
            (
                [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
                [[1], [2], [3]],
                [[1], [2], [3]]
            )
        ],
    )
    def test_solve(self, a, b, x):
        """Test the solve function"""
        t_x = solve(a, b)
        if t_x is None:
            assert t_x == x
        else:
            assert np.allclose(t_x, x)

    @pytest.mark.parametrize(
        "a, b, x",
        [
            (
                [[1, 1, 1], [-1, 1, 1], [-1, -1, 1]],
                [[1], [2], [-1]],
                [[-1 / 2], [3 / 2], [0]],
            ),
            (
                [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
                [[1], [2], [3]],
                [[1], [2], [3]]
            )
        ],
    )
    def test_solve_opt(self, a, b, x):
        """Test the solve_opt function"""
        t_x = solve_opt(a, b)
        if t_x is None:
            assert t_x == x
        else:
            assert np.allclose(t_x, x)
